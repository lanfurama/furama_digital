# services/automation/lighthouse/config.py

EMAIL = "it@furamavietnam.com"
PASSWORD = "Furama@1234"
LOGIN_URL = "https://app.mylighthouse.com/login"
RATES_URL_TEMPLATE = "https://app.mylighthouse.com/hotel/144381/rates?compsetId=1&los=2&maxPersons=2&month={month}&rateParam=lowest&view=table"
